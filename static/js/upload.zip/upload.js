let lastExtractedData = null;
let 
dt; // Declare at the top

function showToast(message, isSuccess = true) {
  const toastEl = $('#toast');
  toastEl.removeClass('text-bg-success text-bg-danger');
  toastEl.addClass(isSuccess ? 'text-bg-success' : 'text-bg-danger');
  toastEl.find('.toast-body').text(message);
  const toast = new bootstrap.Toast(toastEl[0]);
  toast.show();
}

function renderExtractedInvoice(result) {
  console.log("Extracted result:", result)
  lastExtractedData = result;

  const invData = result.invoice_data;
  const invoiceNo = invData.invoice_number;

  // Remove all rows from DataTable
  dt.clear();

  // Add new row using DataTables API
  dt.row.add([
    invoiceNo,
    invData.from_address,
    invData.to_address,
    invData.gst_number,
    invData.invoice_date,
    invData.total,
    invData.taxes,
    invData.total_quantity,
    `<button class="btn btn-sm btn-outline-info toggleItems" data-id="${invoiceNo}">Items</button>`
  ]).draw();

  $('#extractedSection').show();
  $('#saveBtn').prop('disabled', false).text('Save').show();
}



function getItemsTableHtml(items) {
  return `
    <table class="table table-sm table-bordered mb-0" id="editableItemTable">
      <thead class="table-secondary">
        <tr>
          <th>Item ID</th>
          <th>Invoice No</th>
          <th>Description</th>
          <th>HSN</th>
          <th>Quantity</th>
          <th>Price/Unit</th>
          <th>CGST</th>
          <th>IGST</th>
          <th>SGST</th>
          <th>Amount</th>
        </tr>
      </thead>
      <tbody>
        ${items.map(item => `
          <tr data-id="${item.item_id}">
            <td>${item.item_id || "-"}</td>
            <td>${item.invoice_number}</td>
            <td contenteditable="true">${item.description || "-"}</td>
            <td contenteditable="true">${item.hsn || "-"}</td>
            <td contenteditable="true">${item.quantity || "-"}</td>
            <td contenteditable="true">${item.price_per_unit ?? "-"}</td>
            <td contenteditable="true">${item.gst || "-"}</td>
            <td contenteditable="true">${item.igst || "-"}</td>
            <td contenteditable="true">${item.sgst || "-"}</td>
            <td contenteditable="true">${item.amount || "-"}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
    <button class="btn btn-sm btn-success mt-2" id="saveUpdatedItems">💾 Save Items</button>
  `;
}



$('#recentInvoiceTable tbody').on('click', '.toggleItems', function () {
  const tr = $(this).closest('tr');
  const row = dt.row(tr);
  const invoiceNo = $(this).data('id'); // <-- Add this line

  let items = lastExtractedData?.invoice_data?.items;
  if (!Array.isArray(items) || items.length === 0) {
    items = lastExtractedData?.items;
  }

  if (row.child.isShown()) {
    row.child.hide();
    tr.removeClass('shown');
  } else {
    if (Array.isArray(items) && items.length > 0) {
      console.log("Showing child row for invoice:", invoiceNo, items);
      row.child(getItemsTableHtml(items)).show();
      tr.addClass('shown');
    } else {
      showToast("No item data found or already removed.", false);
    }
  }
});


function previewPDF(file) {
  const fileReader = new FileReader();
  fileReader.onload = function () {
    const typedArray = new Uint8Array(this.result);
    pdfjsLib.getDocument(typedArray).promise.then(pdf => {
      pdf.getPage(1).then(page => {
        const canvas = document.getElementById("pdfViewer");
        const context = canvas.getContext("2d");
        const viewport = page.getViewport({ scale: 1.5 });
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        page.render({ canvasContext: context, viewport: viewport });
        $('#pdfViewer').show();
      });
    });
  };
  fileReader.readAsArrayBuffer(file);
}

$('#invoiceFile').on('change', function () {
  const file = this.files[0];
  $('#previewImg').hide();
  $('#pdfViewer').hide();

  if (file) {
    const type = file.type;
    if (type === "application/pdf") {
      previewPDF(file);
    } else if (type.startsWith("image/")) {
      const reader = new FileReader();
      reader.onload = function (e) {
        $('#previewImg').attr('src', e.target.result).show();
      };
      reader.readAsDataURL(file);
    }
  }
});

$('#uploadForm').on('submit', function (e) {
  e.preventDefault();
  const file = $('#invoiceFile')[0].files[0];
  const mode = $('#modeSelect').val();

  if (!file) {
    showToast("Please select a file.", false);
    return;
  }

  const formData = new FormData();
  formData.append("file", file);
  formData.append("mode", mode);

  $.ajax({
    url: '/api/v1/upload-invoice',
    type: 'POST',
    data: formData,
    processData: false,
    contentType: false,
    success: function (resp) {
      console.log("Response from server:", resp);
      showToast("Invoice processed successfully.");
      renderExtractedInvoice(resp);
    },
    error: function (xhr) {
      const msg = xhr.responseJSON?.detail || 'Upload failed.';
      showToast(msg, false);
    }
  });
});

$('#saveBtn').on('click', function () {
  if (!lastExtractedData) {
    showToast("No data to save!", false);
    return;
  }

  $.ajax({
    url: '/api/v1/save-invoice',
    type: 'POST',
    contentType: 'application/json',
    data: JSON.stringify(lastExtractedData),
    success: function () {
      showToast("Invoice saved successfully.");
      $('#saveBtn').prop('disabled', true).text("Saved");
    },
    error: function () {
      showToast("Failed to save invoice.", false);
    }
  });
});

//initialize DataTable for recent invoices
$(document).ready(function() {
  dt = $('#recentInvoiceTable').DataTable({
    paging: false,
    searching: false,
    info: false
  });
});

// Save updated items from editable table to the server
$(document).on('click', '#saveUpdatedItems', function () {
  const updatedItems = [];

  $('#editableItemTable tbody tr').each(function () {
    const row = $(this);
    updatedItems.push({
      item_id: row.data('id'),
      invoice_number: row.find('td:eq(1)').text().trim(),
      description: row.find('td:eq(2)').text().trim(),
      hsn: row.find('td:eq(3)').text().trim(),
      quantity: row.find('td:eq(4)').text().trim(),
      price_per_unit: row.find('td:eq(5)').text().trim(),
      gst: row.find('td:eq(6)').text().trim(),
      igst: row.find('td:eq(7)').text().trim(),
      sgst: row.find('td:eq(8)').text().trim(),
      amount: row.find('td:eq(9)').text().trim()
    });
  });

  $.ajax({
    url: '/api/v1/invoices/update-items',
    type: 'POST',
    contentType: 'application/json',
    data: JSON.stringify(updatedItems),
    success: function () {
      showToast("Items updated successfully.");
    },
    error: function () {
      showToast("Failed to update items.", false);
    }
  });
});
