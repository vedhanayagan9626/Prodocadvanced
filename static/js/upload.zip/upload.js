// Initialize PDF.js
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

// Global variables
let lastExtractedData = null;
let dt; // DataTable instance
let pdfDoc = null;
let currentPage = 1;
let pdfScale = 1.5;
let isPanning = false;
let startX = 0, startY = 0, panX = 0, panY = 0, scale = 1;
let activeElement = null;
const minScale = 0.5, maxScale = 4;

// Make essential functions globally available
window.displayFilePreview = displayFilePreview;
window.processFile = processFile;
window.resetTransform = resetTransform;
window.showToast = showToast;

// Main initialization
$(document).ready(function() {
    initializeApplication();
});

function initializeApplication() {
    // Setup DataTable
    dt = $('#recentInvoiceTable').DataTable({
        paging: false,
        searching: false,
        info: false
    });

    // Handle incoming file parameters
    const urlParams = new URLSearchParams(window.location.search);
    const filename = urlParams.get('file');
    const originalFilename = urlParams.get('original') || filename;
    const mode = urlParams.get('mode') || 'text';
    
    if (filename) {
        // Display the original filename
        $('#currentFilename').text(originalFilename || filename);
        $('#modeSelect').val(mode);
        
        // Display the file preview
        displayFilePreview(filename);
    } else {
        showToast("No file specified for processing", false);
    }

    // Event handlers
    $('#uploadForm').on('submit', handleFormSubmit);
    $('#saveBtn').on('click', handleSaveInvoice);
    $(document).on('click', '#saveUpdatedItems', handleSaveItems);
    $('#recentInvoiceTable tbody').on('click', '.toggleItems', handleToggleItems);
    
    // Initialize pan/zoom
    attachPanZoom(document.getElementById('previewImg'), false);
    attachPanZoom(document.getElementById('pdfViewer'), true);
    
    // Window resize handler
    window.addEventListener('resize', resizePreviewArea);
    resizePreviewArea();
}

// File Processing Functions
function processFile(filename, mode) {
    showGlobalSpinner();
    
    const formData = new FormData();
    formData.append('filename', filename);
    formData.append('mode', mode);

    fetch('/api/v1/upload-invoice', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) throw new Error(response.statusText);
        return response.json();
    })
    .then(data => {
        showToast("Invoice processed successfully");
        renderExtractedInvoice(data);
    })
    .catch(error => {
        showToast(error.message || 'File processing failed', false);
    })
    .finally(() => {
        hideGlobalSpinner();
    });
}

function handleResponse(response) {
    if (!response.ok) {
        throw new Error(response.statusText);
    }
    return response.json();
}

function handleError(error) {
    showToast(error.message || 'File processing failed.', false);
    console.error("Processing error:", error);
}

// Display file preview with proper CORS handling
function displayFilePreview(filename) {
    const fileType = filename.split('.').pop().toLowerCase();
    const previewImg = document.getElementById('previewImg');
    const pdfViewer = document.getElementById('pdfViewer');
    
    // Hide both initially
    previewImg.style.display = 'none';
    pdfViewer.style.display = 'none';

    if (!filename) {
        showToast("No file specified for preview", false);
        return;
    }

    if (fileType === 'pdf') {
        // Load PDF preview
        fetchPDFPreview(filename);
    } else if (['jpg', 'jpeg', 'png'].includes(fileType)) {
        // Load image preview
        fetchImagePreview(filename);
    } else {
        showToast("Unsupported file type for preview", false);
    }
}

function fetchPDFPreview(filename) {
    const pdfViewer = document.getElementById('pdfViewer');
    
    fetch(`/api/v1/get-file?filename=${encodeURIComponent(filename)}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to load PDF');
            return response.blob();
        })
        .then(blob => {
            const objectUrl = URL.createObjectURL(blob);
            return pdfjsLib.getDocument(objectUrl).promise;
        })
        .then(pdf => {
            pdfDoc = pdf;
            return pdf.getPage(1);
        })
        .then(page => {
            const viewport = page.getViewport({ scale: 1.5 });
            pdfViewer.height = viewport.height;
            pdfViewer.width = viewport.width;
            const context = pdfViewer.getContext("2d");
            
            return page.render({
                canvasContext: context,
                viewport: viewport
            });
        })
        .then(() => {
            pdfViewer.style.display = 'block';
        })
        .catch(error => {
            console.error("PDF preview error:", error);
            showToast("Failed to load PDF preview", false);
        });
}

function fetchImagePreview(filename) {
    const previewImg = document.getElementById('previewImg');
    
    fetch(`/api/v1/get-file?filename=${encodeURIComponent(filename)}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to load image');
            return response.blob();
        })
        .then(blob => {
            const objectUrl = URL.createObjectURL(blob);
            previewImg.src = objectUrl;
            previewImg.style.display = 'block';
            
            previewImg.onload = function() {
                URL.revokeObjectURL(objectUrl); // Clean up memory
                resetTransform(previewImg);
            };
            
            previewImg.onerror = function() {
                URL.revokeObjectURL(objectUrl);
                throw new Error('Image failed to load');
            };
        })
        .catch(error => {
            console.error("Image preview error:", error);
            showToast("Failed to load image preview", false);
        });
}

// PDF Rendering Functions
function renderPdfPage(pageNum, scaleVal) {
    pdfDoc.getPage(pageNum).then(page => {
        const viewport = page.getViewport({ scale: scaleVal });
        const pdfViewer = document.getElementById('pdfViewer');
        pdfViewer.height = viewport.height;
        pdfViewer.width = viewport.width;
        const context = pdfViewer.getContext("2d");
        
        page.render({
            canvasContext: context,
            viewport: viewport
        });
        pdfViewer.style.display = 'block';
    });
}

// Pan/Zoom Functions
function attachPanZoom(el, isPDF = false) {
    if (!el) return;
    
    el.onmousedown = function(e) {
        if (el.style.display === 'none') return;
        isPanning = true;
        activeElement = el;
        startX = e.clientX - panX;
        startY = e.clientY - panY;
        el.style.cursor = 'grabbing';
    };
    
    el.onwheel = function(e) {
        if (el.style.display === 'none') return;
        e.preventDefault();
        const delta = e.deltaY > 0 ? -0.1 : 0.1;
        const newScale = Math.min(maxScale, Math.max(minScale, scale + delta));
        if (newScale !== scale) {
            scale = newScale;
            if (isPDF) {
                pdfScale = scale * 1.5;
                renderPdfPage(currentPage, pdfScale);
            } else {
                setTransform(el, panX, panY, scale);
            }
        }
    };
}

function setTransform(el, x, y, scale) {
    el.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
}

function resetTransform(element) {
    if (!element) return;
    element.style.transform = 'translate(0px, 0px) scale(1)';
}

// Event Handlers
function handleFormSubmit(e) {
    e.preventDefault();
    const filename = new URLSearchParams(window.location.search).get('file');
    const mode = $('#modeSelect').val();
    
    if (!filename) {
        showToast("No file to process", false);
        return;
    }
    
    processFile(filename, mode);
}

function handleSaveInvoice() {
    showDatatableSpinner();
    const row = $('#recentInvoiceTable tbody tr').first();
    const updatedInvoice = {};

    row.find('td .editable').each(function() {
        const field = $(this).data('field');
        updatedInvoice[field] = $(this).text().trim();
    });

    $.ajax({
        url: '/api/v1/invoices/update-invoice',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(updatedInvoice),
        success: function() {
            showToast("Invoice updated successfully.");
            $('#saveBtn').prop('disabled', true).text("✅ Updated");
            updateLastExtractedData(updatedInvoice, 'invoice');
        },
        error: function() {
            showToast("Failed to update invoice.", false);
        },
        complete: hideDatatableSpinner
    });
}

function handleSaveItems() {
    const updatedItems = [];
    $('#editableItemTable tbody tr').each(function() {
        const row = $(this);
        updatedItems.push({
            item_id: row.data('id'),
            invoice_number: row.find('td:eq(1)').text().trim(),
            description: row.find('td:eq(2)').text().trim(),
            hsn: row.find('td:eq(3)').text().trim(),
            quantity: row.find('td:eq(4)').text().trim(),
            price_per_unit: row.find('td:eq(5)').text().trim(),
            gst: row.find('td:eq(6)').text().trim(),
            igst: row.find('td:eq(7)').text().trim(),
            sgst: row.find('td:eq(8)').text().trim(),
            amount: row.find('td:eq(9)').text().trim()
        });
    });

    $.ajax({
        url: '/api/v1/invoices/update-items',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(updatedItems),
        success: function() {
            showToast("Items updated successfully.");
            updateLastExtractedData(updatedItems, 'items');
        },
        error: function() {
            showToast("Failed to update items.", false);
        }
    });
}

function handleToggleItems() {
    const tr = $(this).closest('tr');
    const row = dt.row(tr);
    const invoiceNo = $(this).data('id');

    let items = lastExtractedData?.invoice_data?.items || lastExtractedData?.items || [];
    
    if (row.child.isShown()) {
        row.child.hide();
        tr.removeClass('shown');
    } else if (items.length > 0) {
        row.child(getItemsTableHtml(items)).show();
        tr.addClass('shown');
    } else {
        showToast("No item data found", false);
    }
}

// UI Functions
function showToast(message, isSuccess = true) {
    const toastEl = $('#toast');
    toastEl.removeClass('text-bg-success text-bg-danger')
           .addClass(isSuccess ? 'text-bg-success' : 'text-bg-danger')
           .find('.toast-body').text(message);
    new bootstrap.Toast(toastEl[0]).show();
}

function renderExtractedInvoice(result) {
    lastExtractedData = result;
    const invData = result.invoice_data;
    
    dt.clear().row.add([
        createEditableCell('invoice_number', invData.invoice_number),
        createEditableCell('from_address', invData.from_address),
        createEditableCell('to_address', invData.to_address),
        createEditableCell('gst_number', invData.gst_number),
        createEditableCell('invoice_date', invData.invoice_date),
        createEditableCell('total', invData.total),
        createEditableCell('taxes', invData.taxes),
        createEditableCell('total_quantity', invData.total_quantity),
        `<button class="btn btn-sm btn-outline-info toggleItems" data-id="${invData.invoice_number}">Items</button>`
    ]).draw();

    $('#extractedSection').show();
    $('#saveBtn').prop('disabled', false).text('Save').show();
}

function createEditableCell(field, value) {
    return `<span contenteditable="true" class="editable" data-field="${field}">${value}</span>`;
}

function getItemsTableHtml(items) {
    return `
    <table class="table table-sm table-bordered mb-0" id="editableItemTable">
      <thead class="table-secondary">
        <tr>
          <th>Item ID</th>
          <th>Invoice No</th>
          <th>Description</th>
          <th>HSN</th>
          <th>Quantity</th>
          <th>Price/Unit</th>
          <th>CGST</th>
          <th>IGST</th>
          <th>SGST</th>
          <th>Amount</th>
        </tr>
      </thead>
      <tbody>
        ${items.map(item => `
          <tr data-id="${item.item_id || ''}">
            <td>${item.item_id || "-"}</td>
            <td>${item.invoice_number || "-"}</td>
            <td contenteditable="true">${item.description || "-"}</td>
            <td contenteditable="true">${item.hsn || "-"}</td>
            <td contenteditable="true">${item.quantity || "-"}</td>
            <td contenteditable="true">${item.price_per_unit ?? "-"}</td>
            <td contenteditable="true">${item.gst || "-"}</td>
            <td contenteditable="true">${item.igst || "-"}</td>
            <td contenteditable="true">${item.sgst || "-"}</td>
            <td contenteditable="true">${item.amount || "-"}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
    <button class="btn btn-sm btn-success mt-2" id="saveUpdatedItems">💾 Save Items</button>`;
}

function updateLastExtractedData(updatedData, type = 'invoice') {
    if (!lastExtractedData) return;

    if (type === 'invoice' && lastExtractedData.invoice_data) {
        Object.assign(lastExtractedData.invoice_data, updatedData);
    } else if (type === 'items') {
        if (lastExtractedData.invoice_data) {
            lastExtractedData.invoice_data.items = updatedData;
        } else {
            lastExtractedData.items = updatedData;
        }
    }
}

// Utility Functions
function resizePreviewArea() {
    const wrapper = document.getElementById('previewWrapper');
    if (!wrapper) return;
    
    if (pdfDoc && document.getElementById('pdfViewer').style.display !== 'none') {
        renderPdfPage(currentPage, pdfScale);
    }
}

function showGlobalSpinner() {
    $('#globalSpinnerOverlay').show();
}

function hideGlobalSpinner() {
    $('#globalSpinnerOverlay').hide();
}

function showDatatableSpinner() {
    $('#datatableSpinnerOverlay').show();
}

function hideDatatableSpinner() {
    $('#datatableSpinnerOverlay').hide();
}