// Initialize PDF.js
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';


// Global variables
let lastExtractedData = null;
let dt; // DataTable instance
let pdfDoc = null;
let currentPage = 1;
let pdfScale = 1.5;
let isPanning = false;
let startX = 0, startY = 0, panX = 0, panY = 0, scale = 1;
let activeElement = null;
const minScale = 0.5, maxScale = 4;

// Make essential functions globally available
window.displayFilePreview = displayFilePreview;
window.processFile = processFile;
window.resetTransform = resetTransform;
window.showToast = showToast;

// Main initialization
$(document).ready(function() {
    initializeApplication();
});

function initializeApplication() {
    // Setup DataTable
    dt = $('#recentInvoiceTable').DataTable({
        paging: false,
        searching: false,
        info: false
    });
     
    // Handle incoming file parameters from URI
    handleUrlParameters();

    // Event handlers
    $('#uploadForm').on('submit', handleFormSubmit);
    $('#saveBtn').on('click', handleSaveInvoice);
    $('#addItemBtn').on('click', handleAddItem);
    
    // Initialize pan/zoom
    attachPanZoom(document.getElementById('previewImg'), false);
    attachPanZoom(document.getElementById('pdfViewer'), true);
    
    // Window resize handler
    window.addEventListener('resize', resizePreviewArea);
    resizePreviewArea();
    setupPreviewListeners();
}

function handleUrlParameters() {
    const urlParams = new URLSearchParams(window.location.search);
    const filename = urlParams.get('file');
    const originalFilename = urlParams.get('original') || filename;
    const mode = urlParams.get('mode') || 'text';
    
    if (filename) {
        // Display the original filename
        $('#currentFilename').text(originalFilename || filename);
        $('#modeSelect').val(mode);
        
        // Display the file preview
        displayFilePreview(filename);
    } else {
        showToast("No file specified for processing", false);
    }
}

// File Processing Functions
function processFile(filename, mode) {
    showGlobalSpinner();
    
    const formData = new FormData();
    formData.append('filename', filename);
    formData.append('mode', mode);

    fetch('/api/v1/upload-invoice', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (!response.ok) throw new Error(response.statusText);
        return response.json();
    })
    .then(data => {
        showToast("Invoice processed successfully");
        renderExtractedInvoice(data);
        renderInvoicePreview(data); // Render preview with extracted data
    })
    .catch(error => {
        showToast(error.message || 'File processing failed', false);
    })
    .finally(() => {
        hideGlobalSpinner();
    });
}

// Display file preview with proper CORS handling
function displayFilePreview(filename) {
    const fileType = filename.split('.').pop().toLowerCase();
    const previewImg = document.getElementById('previewImg');
    const pdfViewer = document.getElementById('pdfViewer');
    
    // Hide both initially
    previewImg.style.display = 'none';
    pdfViewer.style.display = 'none';

    if (!filename) {
        showToast("No file specified for preview", false);
        return;
    }

    if (fileType === 'pdf') {
        // Load PDF preview
        fetchPDFPreview(filename);
    } else if (['jpg', 'jpeg', 'png'].includes(fileType)) {
        // Load image preview
        fetchImagePreview(filename);
    } else {
        showToast("Unsupported file type for preview", false);
    }
}

function fetchPDFPreview(filename) {
    const pdfViewer = document.getElementById('pdfViewer');
    
    fetch(`/api/v1/get-file?filename=${encodeURIComponent(filename)}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to load PDF');
            return response.blob();
        })
        .then(blob => {
            const objectUrl = URL.createObjectURL(blob);
            return pdfjsLib.getDocument(objectUrl).promise;
        })
        .then(pdf => {
            pdfDoc = pdf;
            return pdf.getPage(1);
        })
        .then(page => {
            const viewport = page.getViewport({ scale: 1.5 });
            pdfViewer.height = viewport.height;
            pdfViewer.width = viewport.width;
            const context = pdfViewer.getContext("2d");
            
            return page.render({
                canvasContext: context,
                viewport: viewport
            });
        })
        .then(() => {
            pdfViewer.style.display = 'block';
        })
        .catch(error => {
            console.error("PDF preview error:", error);
            showToast("Failed to load PDF preview", false);
        });
}

function fetchImagePreview(filename) {
    const previewImg = document.getElementById('previewImg');
    
    fetch(`/api/v1/get-file?filename=${encodeURIComponent(filename)}`)
        .then(response => {
            if (!response.ok) throw new Error('Failed to load image');
            return response.blob();
        })
        .then(blob => {
            const objectUrl = URL.createObjectURL(blob);
            previewImg.src = objectUrl;
            previewImg.style.display = 'block';
            
            previewImg.onload = function() {
                URL.revokeObjectURL(objectUrl); // Clean up memory
                resetTransform(previewImg);
            };
            
            previewImg.onerror = function() {
                URL.revokeObjectURL(objectUrl);
                throw new Error('Image failed to load');
            };
        })
        .catch(error => {
            console.error("Image preview error:", error);
            showToast("Failed to load image preview", false);
        });
}

// PDF Rendering Functions
function renderPdfPage(pageNum, scaleVal) {
    pdfDoc.getPage(pageNum).then(page => {
        const viewport = page.getViewport({ scale: scaleVal });
        const pdfViewer = document.getElementById('pdfViewer');
        pdfViewer.height = viewport.height;
        pdfViewer.width = viewport.width;
        const context = pdfViewer.getContext("2d");
        
        page.render({
            canvasContext: context,
            viewport: viewport
        });
        pdfViewer.style.display = 'block';
    });
}

// Pan/Zoom Functions
function attachPanZoom(el, isPDF = false) {
    if (!el) return;
    
    el.onmousedown = function(e) {
        if (el.style.display === 'none') return;
        isPanning = true;
        activeElement = el;
        startX = e.clientX - panX;
        startY = e.clientY - panY;
        el.style.cursor = 'grabbing';
    };
    
    el.onwheel = function(e) {
        if (el.style.display === 'none') return;
        e.preventDefault();
        const delta = e.deltaY > 0 ? -0.1 : 0.1;
        const newScale = Math.min(maxScale, Math.max(minScale, scale + delta));
        if (newScale !== scale) {
            scale = newScale;
            if (isPDF) {
                pdfScale = scale * 1.5;
                renderPdfPage(currentPage, pdfScale);
            } else {
                setTransform(el, panX, panY, scale);
            }
        }
    };
}

function setTransform(el, x, y, scale) {
    el.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
}

function resetTransform(element) {
    if (!element) return;
    element.style.transform = 'translate(0px, 0px) scale(1)';
}

// Event Handlers
function handleFormSubmit(e) {
    e.preventDefault();
    const filename = new URLSearchParams(window.location.search).get('file');
    const mode = $('#modeSelect').val();
    
    if (!filename) {
        showToast("No file to process", false);
        return;
    }
    
    processFile(filename, mode);
}

function renderExtractedInvoice(result) {
    lastExtractedData = result;
    const invData = result.invoice_data || {};
    const items = result.items || [];
    
    // Populate basic invoice fields
    $('#invoiceNumber').val(invData.invoice_number || '');
    $('#invoiceDate').val(invData.invoice_date || '');
    $('#fromAddress').val(invData.from_address || '');
    $('#toAddress').val(invData.to_address || '');
    $('#supplierGst').val(invData.gst_number || '');
    $('#totalQuantity').val(invData.total_quantity || '');
    $('#total').val(invData.total || '');
    $('#taxDetails').val(invData.taxes || '');
    
    // Render items
    const itemsTableBody = $('#itemsTableBody');
    itemsTableBody.empty();
    
    let subtotal = 0;
    let taxAmount = 0;
    
    items.forEach(item => {
        const amount = parseFloat(item.amount) || 0;
        const taxRate = parseFloat(item.gst || 0);
        subtotal += amount / (1 + (taxRate / 100));
        taxAmount += amount - (amount / (1 + (taxRate / 100)));
        
        itemsTableBody.append(createItemRow(item));
    });
    
    // Calculate totals
    updateTotals(subtotal, taxAmount);
    $('#extractedSection').show();
    
    // Initialize event handlers
    initializeItemHandlers();
}

function createItemRow(item) {
    const amount = parseFloat(item.amount) || 0;
    const taxRate = parseFloat(item.gst) || 0;
    const qty = parseFloat(item.quantity) || 1;
    const rate = amount / (1 + (taxRate / 100)) / qty;
    
    return `
    <tr data-id="${item.item_id || ''}">
        <td><input type="text" class="form-control form-control-sm" value="${item.description || ''}" data-field="description"></td>
        <td><input type="number" class="form-control form-control-sm qty" value="${qty}" data-field="quantity" min="0" step="0.01"></td>
        <td><input type="number" class="form-control form-control-sm rate" value="${rate.toFixed(2)}" data-field="price_per_unit" min="0" step="0.01"></td>
        <td><input type="number" class="form-control form-control-sm tax" value="${taxRate}" data-field="gst" min="0" max="100" step="0.01"></td>
        <td><input type="number" class="form-control form-control-sm amount" value="${amount.toFixed(2)}" data-field="amount" readonly></td>
    </tr>`;
}

function initializeItemHandlers() {
    // Add item button
    $('#addItemBtn').off('click').on('click', handleAddItem);
    
    // Delete item button
    $('#itemsTableBody').off('click', '.delete-item').on('click', '.delete-item', function() {
        $(this).closest('tr').remove();
        calculateInvoiceTotals();
    });
    
    // Input changes
    $('#itemsTableBody').off('input').on('input', '.qty, .rate, .tax', function() {
        const row = $(this).closest('tr');
        calculateRowTotal(row);
        calculateInvoiceTotals();
        renderInvoicePreviewFromForm(); // Update preview when items change
    });
}

function handleAddItem() {
    $('#itemsTableBody').append(`
    <tr>
        <td><input type="text" class="form-control form-control-sm" data-field="description" placeholder="Item description"></td>
        <td><input type="number" class="form-control form-control-sm qty" data-field="quantity" value="1" min="0" step="0.01"></td>
        <td><input type="number" class="form-control form-control-sm rate" data-field="price_per_unit" value="0.00" min="0" step="0.01"></td>
        <td><input type="number" class="form-control form-control-sm tax" data-field="gst" value="18" min="0" max="100" step="0.01"></td>
        <td><input type="number" class="form-control form-control-sm amount" data-field="amount" value="0.00" readonly></td>
    </tr>
    `);
    calculateInvoiceTotals();
    renderInvoicePreviewFromForm();
}

function calculateRowTotal(row) {
    const qty = parseFloat(row.find('.qty').val()) || 0;
    const rate = parseFloat(row.find('.rate').val()) || 0;
    const taxRate = parseFloat(row.find('.tax').val()) || 0;
    
    const subtotal = qty * rate;
    const total = subtotal * (1 + (taxRate / 100));
    
    row.find('.amount').val(total.toFixed(2));
}

function calculateInvoiceTotals() {
    let subtotal = 0;
    let taxAmount = 0;
    
    $('#itemsTableBody tr').each(function() {
        const amount = parseFloat($(this).find('.amount').val()) || 0;
        const taxRate = parseFloat($(this).find('.tax').val()) || 0;
        
        subtotal += amount / (1 + (taxRate / 100));
        taxAmount += amount - (amount / (1 + (taxRate / 100)));
    });
    
    updateTotals(subtotal, taxAmount);
}

function updateTotals(subtotal, taxAmount) {
    $('#subtotal').val(subtotal.toFixed(2));
    $('#taxAmount').val(taxAmount.toFixed(2));
    $('#total').val((subtotal + taxAmount).toFixed(2));
    $('#taxDetails').val(`IGST: ${taxAmount.toFixed(2)}, CGST: 0.00, SGST: 0.00`);
    
    // Update total quantity
    let totalQty = 0;
    $('#itemsTableBody .qty').each(function() {
        totalQty += parseFloat($(this).val()) || 0;
    });
    $('#totalQuantity').val(totalQty.toFixed(2));
}

function renderInvoicePreview(data) {
    const invData = data.invoice_data || {};
    const items = data.items || [];
    
    // Generate items HTML
    let itemsHtml = '';
    items.forEach((item, index) => {
        itemsHtml += `
            <tr>
                <td>${index + 1}</td>
                <td>
                    ${item.description || 'Item'}<br>
                    <span class="item-desc">${item.hsn || ''}</span>
                </td>
                <td>
                    ${item.quantity || '1'}<br>
                    <span class="item-desc">Nos</span>
                </td>
                <td>${(parseFloat(item.price_per_unit) || 0).toFixed(2)}</td>
                <td>0.00</td>
                <td>${item.gst || '0'}%</td>
                <td>${(parseFloat(item.amount) - (parseFloat(item.price_per_unit) * parseFloat(item.quantity)) || 0).toFixed(2)}</td>
                <td>${(parseFloat(item.amount) || 0).toFixed(2)}</td>
            </tr>
        `;
    });

    
     // Calculate totals
    const subtotal = items.reduce((sum, item) => sum + (parseFloat(item.amount) || 0), 0);
    const taxAmount = items.reduce((sum, item) => {
        const rate = parseFloat(item.gst) || 0;
        const amount = parseFloat(item.amount) || 0;
        return sum + (amount - (amount / (1 + (rate / 100))));
    }, 0);
    
    // Generate the invoice HTML
    const invoiceHtml = `
        <div class="header">
            <div class="company-info">
                <div class="company-name">${$('#fromAddress').val().split('\n')[0] || 'Your Company'}</div>
                <div>${$('#fromAddress').val().replace(/\n/g, '<br>') || 'Address'}</div>
            </div>
            <div class="invoice-title">
                <div class="invoice-type">TAX INVOICE</div>
                <div class="invoice-number"># ${$('#invoiceNumber').val() || 'INV-001'}</div>
                <div class="balance-due">
                    <div class="balance-label">Balance Due</div>
                    <div class="balance-amount">₹${$('#total').val() || '0.00'}</div>
                </div>
            </div>
        </div>

        <div class="address-section">
            <div class="bill-to">
                <div class="address-label">Bill To</div>
                <div>
                    <span class="customer-name">${$('#toAddress').val().split('\n')[0] || 'Customer'}</span><br>
                    ${$('#toAddress').val().replace(/\n/g, '<br>') || 'Address'}
                </div>
            </div>
            <div class="invoice-details">
                <table>
                    <tr>
                        <td>Invoice Date:</td>
                        <td class="text-right">${$('#invoiceDate').val() || new Date().toLocaleDateString()}</td>
                    </tr>
                    <tr>
                        <td>GSTIN:</td>
                        <td class="text-right">${$('#supplierGst').val() || ''}</td>
                    </tr>
                </table>
            </div>
        </div>

        <table class="items-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Item & Description</th>
                    <th>Qty</th>
                    <th>Rate</th>
                    <th>Discount</th>
                    <th>Tax %</th>
                    <th>Tax</th>
                    <th>Amount</th>
                </tr>
            </thead>
            <tbody>
                ${itemsHtml}
            </tbody>
        </table>

        <div class="totals-container">
            <div class="notes-section">
                <div class="terms-label">Notes</div>
                <div>${$('#taxDetails').val() || ''}</div>
            </div>
            <div class="totals-section">
                <table class="totals-table">
                    <tr>
                        <td class="total-label">Sub Total</td>
                        <td class="total-value">${subtotal.toFixed(2)}</td>
                    </tr>
                    <tr>
                        <td class="total-label">Tax Amount</td>
                        <td class="total-value">${taxAmount.toFixed(2)}</td>
                    </tr>
                    <tr class="balance-row">
                        <td class="total-label"><b>Total</b></td>
                        <td class="total-value"><b>₹${(subtotal + taxAmount).toFixed(2)}</b></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="signature-section">
            <div class="terms-label">Authorized Signature</div>
            <div class="signature-line"></div>
        </div>

        <div class="footer">
            <div class="text-center">Thank you for your business!</div>
        </div>
    `;
    
    $('#invoice-preview').html(invoiceHtml);
}

// Render preview from form data
function renderInvoicePreviewFromForm() {
    const items = [];
    
    $('#itemsTableBody tr').each(function() {
        const row = $(this);
        items.push({
            description: row.find('input[data-field="description"]').val() || 'Item',
            quantity: row.find('input[data-field="quantity"]').val() || '1',
            price_per_unit: row.find('input[data-field="price_per_unit"]').val() || '0',
            gst: row.find('input[data-field="gst"]').val() || '0',
            amount: row.find('input[data-field="amount"]').val() || '0'
        });
    });
    
    renderInvoicePreview({
        invoice_data: {
            invoice_number: $('#invoiceNumber').val(),
            invoice_date: $('#invoiceDate').val(),
            from_address: $('#fromAddress').val(),
            to_address: $('#toAddress').val(),
            gst_number: $('#supplierGst').val(),
            total_quantity: $('#totalQuantity').val(),
            total: $('#total').val(),
            taxes: $('#taxDetails').val()
        },
        items: items
    });
}

// Set up event listeners for form changes to update preview
function setupPreviewListeners() {
    $('#invoiceForm input, #invoiceForm textarea').on('input', function() {
        renderInvoicePreviewFromForm();
    });
}

function handleSaveInvoice() {
    showDatatableSpinner();
    const updatedInvoice = {
        invoice_data: {},
        items: []
    };
    
    // Collect basic invoice data
    $('#invoiceForm input, #invoiceForm textarea').each(function() {
        const field = $(this).data('field');
        if (field) {
            updatedInvoice.invoice_data[field] = $(this).val();
        }
    });
    
    // Collect items data
    $('#itemsTableBody tr').each(function() {
        const row = $(this);
        const item = {};
        
        row.find('input').each(function() {
            const field = $(this).data('field');
            if (field) {
                item[field] = $(this).val();
            }
        });
        
        if (Object.keys(item).length > 0) {
            updatedInvoice.items.push(item);
        }
    });
    
    $.ajax({
        url: '/api/v1/invoices/update-invoice',
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify(updatedInvoice),
        success: function() {
            showToast("Invoice updated successfully.");
            $('#saveBtn').html('<i class="bi bi-check-circle"></i> Saved').prop('disabled', true);
            updateLastExtractedData(updatedInvoice);
        },
        error: function() {
            showToast("Failed to update invoice.", false);
        },
        complete: hideDatatableSpinner
    });
}


function updateLastExtractedData(updatedData) {
    if (!lastExtractedData) return;
    
    // Update invoice data
    if (updatedData.invoice_data) {
        lastExtractedData.invoice_data = {...lastExtractedData.invoice_data, ...updatedData.invoice_data};
    }
    
    // Update items
    if (updatedData.items) {
        lastExtractedData.items = updatedData.items;
    }
}

// UI Functions
function showToast(message, isSuccess = true) {
    const toastEl = $('#toast');
    toastEl.removeClass('text-bg-success text-bg-danger')
           .addClass(isSuccess ? 'text-bg-success' : 'text-bg-danger')
           .find('.toast-body').text(message);
    new bootstrap.Toast(toastEl[0]).show();
}

// Utility Functions
function resizePreviewArea() {
    const wrapper = document.getElementById('previewWrapper');
    if (!wrapper) return;
    
    if (pdfDoc && document.getElementById('pdfViewer').style.display !== 'none') {
        renderPdfPage(currentPage, pdfScale);
    }
}

function showGlobalSpinner() {
    $('#globalSpinnerOverlay').show();
}

function hideGlobalSpinner() {
    $('#globalSpinnerOverlay').hide();
}

function showDatatableSpinner() {
    $('#datatableSpinnerOverlay').show();
}

function hideDatatableSpinner() {
    $('#datatableSpinnerOverlay').hide();
}